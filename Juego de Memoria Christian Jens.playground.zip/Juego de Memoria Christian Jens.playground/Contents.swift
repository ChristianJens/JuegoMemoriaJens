//: Playground - noun: a place where people can play

import UIKit

//var str = "Hello, playground"

var numeros = 0...100

for numero in numeros{
    /*switch numero{
    case 30...40: print("\(numero) Viva Swift")
        break
    }*/
    if(numero >= 30 && numero <= 40){
        print("\(numero) Viva Swift!!!")
    }
    else if(numero % 5 == 0){
        print("\(numero) Bingo!!!")
    }else if(numero % 2 == 0){
        print("\(numero) par!!!")
    }else{
        print("\(numero) impar!!!")
    }
}